"""HelloAgents智能旅行助手 - 后端应用"""

__version__ = "1.0.0"

